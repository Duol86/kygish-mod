
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kygish.init;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;

public class KygishModTabs {
	public static CreativeModeTab TAB_KYGISH;

	public static void load() {
		TAB_KYGISH = new CreativeModeTab("tabkygish") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(KygishModBlocks.ASHWOOD_LOG.get());
			}

			@Override
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
}
