
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kygish.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.kygish.block.YsianStoneBlock;
import net.mcreator.kygish.block.MakaStoneBlock;
import net.mcreator.kygish.block.MakaPortalBlock;
import net.mcreator.kygish.block.KalhiumOreBlock;
import net.mcreator.kygish.block.KalhiumDeepslateOreBlock;
import net.mcreator.kygish.block.ConcentratedLiquidAnabhBlock;
import net.mcreator.kygish.block.AshwoodStairsBlock;
import net.mcreator.kygish.block.AshwoodSlabBlock;
import net.mcreator.kygish.block.AshwoodLogBlock;
import net.mcreator.kygish.block.AshPlanksBlock;
import net.mcreator.kygish.block.AnabhiumOreBlock;
import net.mcreator.kygish.block.AnabhiumDeepslateOreBlock;
import net.mcreator.kygish.KygishMod;

public class KygishModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, KygishMod.MODID);
	public static final RegistryObject<Block> YSIAN_STONE = REGISTRY.register("ysian_stone", () -> new YsianStoneBlock());
	public static final RegistryObject<Block> MAKA_STONE = REGISTRY.register("maka_stone", () -> new MakaStoneBlock());
	public static final RegistryObject<Block> MAKA_PORTAL = REGISTRY.register("maka_portal", () -> new MakaPortalBlock());
	public static final RegistryObject<Block> ASHWOOD_LOG = REGISTRY.register("ashwood_log", () -> new AshwoodLogBlock());
	public static final RegistryObject<Block> ASH_PLANKS = REGISTRY.register("ash_planks", () -> new AshPlanksBlock());
	public static final RegistryObject<Block> ASHWOOD_STAIRS = REGISTRY.register("ashwood_stairs", () -> new AshwoodStairsBlock());
	public static final RegistryObject<Block> ASHWOOD_SLAB = REGISTRY.register("ashwood_slab", () -> new AshwoodSlabBlock());
	public static final RegistryObject<Block> CONCENTRATED_LIQUID_ANABH = REGISTRY.register("concentrated_liquid_anabh",
			() -> new ConcentratedLiquidAnabhBlock());
	public static final RegistryObject<Block> ANABHIUM_ORE = REGISTRY.register("anabhium_ore", () -> new AnabhiumOreBlock());
	public static final RegistryObject<Block> ANABHIUM_DEEPSLATE_ORE = REGISTRY.register("anabhium_deepslate_ore",
			() -> new AnabhiumDeepslateOreBlock());
	public static final RegistryObject<Block> KALHIUM_ORE = REGISTRY.register("kalhium_ore", () -> new KalhiumOreBlock());
	public static final RegistryObject<Block> KALHIUM_DEEPSLATE_ORE = REGISTRY.register("kalhium_deepslate_ore",
			() -> new KalhiumDeepslateOreBlock());
}
