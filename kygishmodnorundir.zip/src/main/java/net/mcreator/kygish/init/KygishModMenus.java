
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kygish.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.MenuType;

import net.mcreator.kygish.world.inventory.DimensionTravelGuiMenu;
import net.mcreator.kygish.KygishMod;

public class KygishModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, KygishMod.MODID);
	public static final RegistryObject<MenuType<DimensionTravelGuiMenu>> DIMENSION_TRAVEL_GUI = REGISTRY.register("dimension_travel_gui",
			() -> IForgeMenuType.create(DimensionTravelGuiMenu::new));
}
