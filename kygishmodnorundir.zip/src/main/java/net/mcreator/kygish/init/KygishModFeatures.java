
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kygish.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.levelgen.feature.Feature;

import net.mcreator.kygish.world.features.ores.YsianStoneFeature;
import net.mcreator.kygish.world.features.ores.MakaStoneFeature;
import net.mcreator.kygish.world.features.lakes.ConcentratedLiquidAnabhFeature;
import net.mcreator.kygish.KygishMod;

@Mod.EventBusSubscriber
public class KygishModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.FEATURES, KygishMod.MODID);
	public static final RegistryObject<Feature<?>> YSIAN_STONE = REGISTRY.register("ysian_stone", YsianStoneFeature::feature);
	public static final RegistryObject<Feature<?>> MAKA_STONE = REGISTRY.register("maka_stone", MakaStoneFeature::feature);
	public static final RegistryObject<Feature<?>> CONCENTRATED_LIQUID_ANABH = REGISTRY.register("concentrated_liquid_anabh",
			ConcentratedLiquidAnabhFeature::feature);
}
