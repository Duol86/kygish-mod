
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kygish.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fluids.FluidType;

import net.mcreator.kygish.fluid.types.ConcentratedLiquidAnabhFluidType;
import net.mcreator.kygish.KygishMod;

public class KygishModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(ForgeRegistries.Keys.FLUID_TYPES, KygishMod.MODID);
	public static final RegistryObject<FluidType> CONCENTRATED_LIQUID_ANABH_TYPE = REGISTRY.register("concentrated_liquid_anabh",
			() -> new ConcentratedLiquidAnabhFluidType());
}
