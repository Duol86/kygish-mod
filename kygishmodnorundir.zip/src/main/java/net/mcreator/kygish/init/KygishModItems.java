
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kygish.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.kygish.item.YsianSwordItem;
import net.mcreator.kygish.item.YsianShovelItem;
import net.mcreator.kygish.item.YsianPickaxeItem;
import net.mcreator.kygish.item.YsianHoeItem;
import net.mcreator.kygish.item.YsianAxeItem;
import net.mcreator.kygish.item.TrueYsianSwordItem;
import net.mcreator.kygish.item.RefinedYsianStoneIngotItem;
import net.mcreator.kygish.item.RefinedAnabhiumIngotItem;
import net.mcreator.kygish.item.RawAnabhiumItem;
import net.mcreator.kygish.item.OrbOfDimensionsItem;
import net.mcreator.kygish.item.MakaItem;
import net.mcreator.kygish.item.ConcentratedLiquidAnabhItem;
import net.mcreator.kygish.KygishMod;

public class KygishModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, KygishMod.MODID);
	public static final RegistryObject<Item> YSIAN_STONE = block(KygishModBlocks.YSIAN_STONE, KygishModTabs.TAB_KYGISH);
	public static final RegistryObject<Item> YSIAN_PICKAXE = REGISTRY.register("ysian_pickaxe", () -> new YsianPickaxeItem());
	public static final RegistryObject<Item> YSIAN_AXE = REGISTRY.register("ysian_axe", () -> new YsianAxeItem());
	public static final RegistryObject<Item> YSIAN_SWORD = REGISTRY.register("ysian_sword", () -> new YsianSwordItem());
	public static final RegistryObject<Item> TRUE_YSIAN_SWORD = REGISTRY.register("true_ysian_sword", () -> new TrueYsianSwordItem());
	public static final RegistryObject<Item> REFINED_YSIAN_STONE_INGOT = REGISTRY.register("refined_ysian_stone_ingot",
			() -> new RefinedYsianStoneIngotItem());
	public static final RegistryObject<Item> YSIAN_SHOVEL = REGISTRY.register("ysian_shovel", () -> new YsianShovelItem());
	public static final RegistryObject<Item> YSIAN_HOE = REGISTRY.register("ysian_hoe", () -> new YsianHoeItem());
	public static final RegistryObject<Item> MAKA_STONE = block(KygishModBlocks.MAKA_STONE, KygishModTabs.TAB_KYGISH);
	public static final RegistryObject<Item> MAKA = REGISTRY.register("maka", () -> new MakaItem());
	public static final RegistryObject<Item> ASHWOOD_LOG = block(KygishModBlocks.ASHWOOD_LOG, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ASH_PLANKS = block(KygishModBlocks.ASH_PLANKS, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ASHWOOD_STAIRS = block(KygishModBlocks.ASHWOOD_STAIRS, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ASHWOOD_SLAB = block(KygishModBlocks.ASHWOOD_SLAB, KygishModTabs.TAB_KYGISH);
	public static final RegistryObject<Item> CONCENTRATED_LIQUID_ANABH_BUCKET = REGISTRY.register("concentrated_liquid_anabh_bucket",
			() -> new ConcentratedLiquidAnabhItem());
	public static final RegistryObject<Item> ORB_OF_DIMENSIONS = REGISTRY.register("orb_of_dimensions", () -> new OrbOfDimensionsItem());
	public static final RegistryObject<Item> RAW_ANABHIUM = REGISTRY.register("raw_anabhium", () -> new RawAnabhiumItem());
	public static final RegistryObject<Item> ANABHIUM_ORE = block(KygishModBlocks.ANABHIUM_ORE, KygishModTabs.TAB_KYGISH);
	public static final RegistryObject<Item> ANABHIUM_DEEPSLATE_ORE = block(KygishModBlocks.ANABHIUM_DEEPSLATE_ORE, KygishModTabs.TAB_KYGISH);
	public static final RegistryObject<Item> REFINED_ANABHIUM_INGOT = REGISTRY.register("refined_anabhium_ingot",
			() -> new RefinedAnabhiumIngotItem());
	public static final RegistryObject<Item> KALHIUM_ORE = block(KygishModBlocks.KALHIUM_ORE, KygishModTabs.TAB_KYGISH);
	public static final RegistryObject<Item> KALHIUM_DEEPSLATE_ORE = block(KygishModBlocks.KALHIUM_DEEPSLATE_ORE, KygishModTabs.TAB_KYGISH);

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
