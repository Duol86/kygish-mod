
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kygish.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import net.mcreator.kygish.fluid.ConcentratedLiquidAnabhFluid;
import net.mcreator.kygish.KygishMod;

public class KygishModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(ForgeRegistries.FLUIDS, KygishMod.MODID);
	public static final RegistryObject<FlowingFluid> CONCENTRATED_LIQUID_ANABH = REGISTRY.register("concentrated_liquid_anabh",
			() -> new ConcentratedLiquidAnabhFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_CONCENTRATED_LIQUID_ANABH = REGISTRY.register("flowing_concentrated_liquid_anabh",
			() -> new ConcentratedLiquidAnabhFluid.Flowing());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(CONCENTRATED_LIQUID_ANABH.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_CONCENTRATED_LIQUID_ANABH.get(), RenderType.translucent());
		}
	}
}
