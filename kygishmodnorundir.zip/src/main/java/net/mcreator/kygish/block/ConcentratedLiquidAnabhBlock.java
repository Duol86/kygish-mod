
package net.mcreator.kygish.block;

import net.minecraft.world.level.material.Material;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.kygish.init.KygishModFluids;

public class ConcentratedLiquidAnabhBlock extends LiquidBlock {
	public ConcentratedLiquidAnabhBlock() {
		super(() -> KygishModFluids.CONCENTRATED_LIQUID_ANABH.get(),
				BlockBehaviour.Properties.of(Material.WATER).strength(100f).noCollission().noLootTable());
	}
}
