
package net.mcreator.kygish.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.kygish.init.KygishModItems;
import net.mcreator.kygish.init.KygishModFluids;
import net.mcreator.kygish.init.KygishModFluidTypes;
import net.mcreator.kygish.init.KygishModBlocks;

public abstract class ConcentratedLiquidAnabhFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(
			() -> KygishModFluidTypes.CONCENTRATED_LIQUID_ANABH_TYPE.get(), () -> KygishModFluids.CONCENTRATED_LIQUID_ANABH.get(),
			() -> KygishModFluids.FLOWING_CONCENTRATED_LIQUID_ANABH.get()).explosionResistance(100f).tickRate(3)
			.bucket(() -> KygishModItems.CONCENTRATED_LIQUID_ANABH_BUCKET.get())
			.block(() -> (LiquidBlock) KygishModBlocks.CONCENTRATED_LIQUID_ANABH.get());

	private ConcentratedLiquidAnabhFluid() {
		super(PROPERTIES);
	}

	public static class Source extends ConcentratedLiquidAnabhFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends ConcentratedLiquidAnabhFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
